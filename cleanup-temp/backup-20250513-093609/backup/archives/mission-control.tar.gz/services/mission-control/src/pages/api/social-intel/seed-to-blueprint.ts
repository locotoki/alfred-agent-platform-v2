import type { NextApiRequest, NextApiResponse } from 'next';
import { createServerSupabaseClient } from '@supabase/auth-helpers-nextjs';

// Social Intel service URL
const SOCIAL_INTEL_SERVICE_URL = process.env.SOCIAL_INTEL_SERVICE_URL || 'http://social-intel:8000';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Create authenticated Supabase client
    const supabase = createServerSupabaseClient({ req, res });
    
    // Check if user is authenticated
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get the query parameters
    const { video_url, niche } = req.query;
    
    if (!video_url && !niche) {
      return res.status(400).json({ error: 'Either video_url or niche parameter must be provided' });
    }
    
    // Call the Social Intel service
    const params = new URLSearchParams();
    if (video_url) {
      params.append('video_url', video_url as string);
    }
    if (niche) {
      params.append('niche', niche as string);
    }

    const response = await fetch(`${SOCIAL_INTEL_SERVICE_URL}/seed-to-blueprint?${params.toString()}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const error = await response.json();
      return res.status(response.status).json({ error: error.detail || 'Error calling Social Intel service' });
    }

    const result = await response.json();

    // Save the result to Supabase
    const { data, error } = await supabase
      .from('workflow_results')
      .insert({
        workflow_type: 'seed-to-blueprint',
        parameters: { video_url, niche },
        result,
        user_id: session.user.id,
      })
      .select()
      .single();

    if (error) {
      console.error('Error saving workflow result to database:', error);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in seed-to-blueprint API route:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}