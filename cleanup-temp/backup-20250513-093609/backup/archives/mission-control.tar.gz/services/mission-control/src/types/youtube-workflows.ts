export interface YouTubeNiche {
  query: string;
  view_sum: number;
  rsv: number;
  view_rank: number;
  rsv_rank: number;
  score: number;
  x: number;
  y: number;
  niche: number;
}

export interface YouTubeVideo {
  video_id: string;
  title: string;
  channel_id: string;
  channel_name: string;
  view_count: number;
  like_count?: number;
  comment_count?: number;
  published_at: string;
  duration: string;
  tags: string[];
  description: string;
}

export interface YouTubeChannel {
  channel_id: string;
  channel_name: string;
  subscribers: number;
  total_views: number;
  video_count: number;
  recent_upload_count: number;
  thirty_day_delta: number;
  primary_topics: string[];
  format_distribution?: Record<string, number>;
}

export interface YouTubeGap {
  keyword: string;
  seed_coverage: number;
  competitor_coverage: Record<string, number>;
  opportunity_score: number;
}

export interface YouTubeBlueprint {
  positioning: string;
  content_pillars: string[];
  format_mix: Record<string, number>;
  roadmap: Record<string, string[]>;
  ai_production_tips: string[];
  coppa_checklist: Array<{
    item: string;
    status: string;
  }>;
}

export interface NicheScoutResult {
  run_date: string;
  trending_niches: YouTubeNiche[];
  top_niches: YouTubeNiche[];
  visualization_url?: string;
  _files?: {
    json_report: string;
    report_file: string;
  };
}

export interface BlueprintResult {
  run_date: string;
  seed_url: string;
  seed_data: YouTubeVideo;
  top_channels: YouTubeChannel[];
  gap_analysis: YouTubeGap[];
  blueprint: YouTubeBlueprint;
  blueprint_url: string;
  _files?: {
    json_report: string;
    report_file: string;
  };
}

export interface WorkflowSchedule {
  id: string;
  workflow_type: 'niche-scout' | 'seed-to-blueprint';
  parameters: Record<string, any>;
  frequency: 'daily' | 'weekly' | 'monthly' | 'once';
  next_run: string;
  status: 'scheduled' | 'running' | 'completed' | 'error';
  created_at: string;
  updated_at: string;
  user_id: string;
}

export interface WorkflowHistory {
  id: string;
  workflow_type: 'niche-scout' | 'seed-to-blueprint';
  parameters: Record<string, any>;
  status: 'running' | 'completed' | 'error';
  started_at: string;
  completed_at?: string;
  result_url?: string;
  user_id: string;
}