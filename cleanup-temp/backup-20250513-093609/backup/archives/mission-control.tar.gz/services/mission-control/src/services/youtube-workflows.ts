import { NicheScoutResult, BlueprintResult, WorkflowHistory, WorkflowSchedule } from '../types/youtube-workflows';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
const SOCIAL_INTEL_URL = `${API_URL}/api/social-intel`;

/**
 * Run the Niche-Scout workflow to find trending YouTube niches
 */
export async function runNicheScout(query?: string): Promise<NicheScoutResult> {
  const params = new URLSearchParams();
  if (query) {
    params.append('query', query);
  }

  const response = await fetch(`${SOCIAL_INTEL_URL}/niche-scout?${params.toString()}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to run Niche-Scout workflow');
  }

  return response.json();
}

/**
 * Run the Seed-to-Blueprint workflow to create a channel strategy
 */
export async function runSeedToBlueprint(params: { video_url?: string; niche?: string }): Promise<BlueprintResult> {
  const urlParams = new URLSearchParams();
  if (params.video_url) {
    urlParams.append('video_url', params.video_url);
  }
  if (params.niche) {
    urlParams.append('niche', params.niche);
  }

  const response = await fetch(`${SOCIAL_INTEL_URL}/seed-to-blueprint?${urlParams.toString()}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to run Seed-to-Blueprint workflow');
  }

  return response.json();
}

/**
 * Get workflow history
 */
export async function getWorkflowHistory(): Promise<WorkflowHistory[]> {
  const response = await fetch(`${SOCIAL_INTEL_URL}/workflow-history`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to get workflow history');
  }

  return response.json();
}

/**
 * Get scheduled workflows
 */
export async function getScheduledWorkflows(): Promise<WorkflowSchedule[]> {
  const response = await fetch(`${SOCIAL_INTEL_URL}/scheduled-workflows`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to get scheduled workflows');
  }

  return response.json();
}

/**
 * Schedule a workflow
 */
export async function scheduleWorkflow(data: {
  workflow_type: 'niche-scout' | 'seed-to-blueprint';
  parameters: Record<string, any>;
  frequency: 'daily' | 'weekly' | 'monthly' | 'once';
  next_run: string;
}): Promise<WorkflowSchedule> {
  const response = await fetch(`${SOCIAL_INTEL_URL}/schedule-workflow`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to schedule workflow');
  }

  return response.json();
}

/**
 * Get workflow result by ID
 */
export async function getWorkflowResult(id: string, type: 'niche-scout' | 'seed-to-blueprint'): Promise<NicheScoutResult | BlueprintResult> {
  const response = await fetch(`${SOCIAL_INTEL_URL}/workflow-result/${id}?type=${type}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to get workflow result');
  }

  return response.json();
}