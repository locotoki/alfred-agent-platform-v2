import { useEffect, useState } from 'react';
import MainLayout from '../components/layout/MainLayout';
import { useQuery } from 'react-query';
import { getWorkflowHistory } from '../services/youtube-workflows';
import { format } from 'date-fns';
import { FiActivity, FiAlertTriangle, FiArrowUp, FiArrowDown, FiCpu, FiDatabase, FiServer, FiUsers, FiRefreshCw, FiClock, FiCheckCircle, FiXCircle } from 'react-icons/fi';

// Mock data for charts
const generateChartData = () => {
  const data = [];
  for (let i = 0; i < 24; i++) {
    data.push({
      hour: i,
      cpu: Math.floor(Math.random() * 40) + 10,
      memory: Math.floor(Math.random() * 30) + 20,
      tasks: Math.floor(Math.random() * 10)
    });
  }
  return data;
};

export default function Dashboard() {
  // Fetch workflow history
  const { data: workflowHistory, isLoading } = useQuery('workflowHistory', getWorkflowHistory, {
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const [systemMetrics, setSystemMetrics] = useState({
    cpuUsage: 27,
    memoryUsage: 42,
    activeTasks: 12,
    successRate: 98.5,
    errorRate: 1.5,
    totalAgents: 8,
    activeAgents: 6
  });

  const chartData = generateChartData();

  return (
    <MainLayout title="Dashboard">
      <div className="space-y-8">
        {/* Welcome Section with Summary */}
        <div className="dashboard-card-gradient p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
                Welcome to Mission Control
              </h1>
              <p className="mt-1 text-gray-600 dark:text-gray-400">
                Platform overview and real-time monitoring
              </p>
            </div>
            <button className="btn-gradient-primary flex items-center">
              <FiRefreshCw className="mr-2" /> Refresh Dashboard
            </button>
          </div>
        </div>

        {/* System Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* CPU Usage */}
          <div className="stat-card">
            <div className="flex justify-between items-start">
              <div>
                <span className="stat-label">CPU Usage</span>
                <div className="stat-value">{systemMetrics.cpuUsage}%</div>
                <div className="stat-trend-up mt-2">
                  <FiArrowUp className="mr-1" /> 2.1% from last hour
                </div>
              </div>
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <FiCpu className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <div className="mt-4 w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${
                  systemMetrics.cpuUsage > 80 ? 'bg-danger-500' : 
                  systemMetrics.cpuUsage > 60 ? 'bg-warning-500' : 'bg-primary-500'
                }`} 
                style={{ width: `${systemMetrics.cpuUsage}%` }}
              ></div>
            </div>
          </div>

          {/* Memory Usage */}
          <div className="stat-card">
            <div className="flex justify-between items-start">
              <div>
                <span className="stat-label">Memory Usage</span>
                <div className="stat-value">{systemMetrics.memoryUsage}%</div>
                <div className="stat-trend-down mt-2">
                  <FiArrowDown className="mr-1" /> 1.3% from last hour
                </div>
              </div>
              <div className="p-3 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                <FiDatabase className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              </div>
            </div>
            <div className="mt-4 w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${
                  systemMetrics.memoryUsage > 80 ? 'bg-danger-500' : 
                  systemMetrics.memoryUsage > 60 ? 'bg-warning-500' : 'bg-success-500'
                }`} 
                style={{ width: `${systemMetrics.memoryUsage}%` }}
              ></div>
            </div>
          </div>

          {/* Active Tasks */}
          <div className="stat-card">
            <div className="flex justify-between items-start">
              <div>
                <span className="stat-label">Active Tasks</span>
                <div className="stat-value">{systemMetrics.activeTasks}</div>
                <div className="stat-trend-up mt-2">
                  <FiArrowUp className="mr-1" /> 3 more than yesterday
                </div>
              </div>
              <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                <FiActivity className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <div className="mt-4 flex space-x-1">
              {Array.from({ length: Math.min(systemMetrics.activeTasks, 15) }).map((_, i) => (
                <div 
                  key={i} 
                  className="flex-1 h-2 rounded-full bg-success-500"
                  style={{ opacity: 1 - (i * 0.05) }}
                ></div>
              ))}
            </div>
          </div>

          {/* Success Rate */}
          <div className="stat-card">
            <div className="flex justify-between items-start">
              <div>
                <span className="stat-label">Success Rate</span>
                <div className="stat-value">{systemMetrics.successRate}%</div>
                <div className="stat-trend-up mt-2">
                  <FiArrowUp className="mr-1" /> 0.5% improvement
                </div>
              </div>
              <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <FiCheckCircle className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div className="bg-success-500 h-2 rounded-full" style={{ width: `${systemMetrics.successRate}%` }}></div>
              </div>
              <span className="ml-2 text-xs font-medium">{systemMetrics.successRate}%</span>
            </div>
          </div>
        </div>

        {/* Middle Row - Agent Status and Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agent Status */}
          <div className="dashboard-card col-span-1 p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Agent Status</h2>
              <span className="badge-gradient-primary">
                {systemMetrics.activeAgents} / {systemMetrics.totalAgents} Online
              </span>
            </div>
            
            <div className="space-y-4">
              <div className="border dark:border-gray-700 rounded-lg p-4 transition-all hover:border-primary-500 dark:hover:border-primary-500">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium flex items-center">
                    <div className="mr-2 h-2 w-2 rounded-full bg-success-500 pulse-dot"></div>
                    Alfred Bot
                  </h3>
                  <span className="badge-gradient-success">ONLINE</span>
                </div>
                <div className="mt-2 flex flex-col space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">CPU:</span>
                    <div className="flex items-center w-24">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mr-2">
                        <div className="bg-primary-500 h-1.5 rounded-full" style={{ width: '12%' }}></div>
                      </div>
                      <span>12%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Memory:</span>
                    <div className="flex items-center w-24">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mr-2">
                        <div className="bg-primary-500 h-1.5 rounded-full" style={{ width: '8%' }}></div>
                      </div>
                      <span>8%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Tasks:</span>
                    <span className="font-medium">3 running</span>
                  </div>
                </div>
              </div>

              <div className="border dark:border-gray-700 rounded-lg p-4 transition-all hover:border-primary-500 dark:hover:border-primary-500">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium flex items-center">
                    <div className="mr-2 h-2 w-2 rounded-full bg-success-500 pulse-dot"></div>
                    Social Intel
                  </h3>
                  <span className="badge-gradient-success">ONLINE</span>
                </div>
                <div className="mt-2 flex flex-col space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">CPU:</span>
                    <div className="flex items-center w-24">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mr-2">
                        <div className="bg-warning-500 h-1.5 rounded-full" style={{ width: '38%' }}></div>
                      </div>
                      <span>38%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Memory:</span>
                    <div className="flex items-center w-24">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mr-2">
                        <div className="bg-primary-500 h-1.5 rounded-full" style={{ width: '25%' }}></div>
                      </div>
                      <span>25%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Tasks:</span>
                    <span className="font-medium">5 running</span>
                  </div>
                </div>
              </div>

              <button className="btn-sm text-primary-600 dark:text-primary-400 hover:underline font-medium w-full text-center">
                View All Agents →
              </button>
            </div>
          </div>

          {/* System Activity Feed */}
          <div className="dashboard-card col-span-1 lg:col-span-2 p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Activity Feed</h2>
              <button className="btn-sm flex items-center text-primary-600 dark:text-primary-400">
                <FiRefreshCw className="mr-1 h-3 w-3" /> Refresh
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="relative">
                <div className="absolute top-0 left-5 h-full w-0.5 bg-gray-200 dark:bg-gray-700"></div>
                {/* Activity item 1 */}
                <div className="relative flex items-start mb-6">
                  <span className="h-10 w-10 flex items-center justify-center rounded-full bg-green-100 dark:bg-green-900 z-10">
                    <FiCheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                  </span>
                  <div className="ml-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <p className="font-medium text-gray-900 dark:text-white">Task Completed</p>
                      <span className="text-sm text-gray-500 dark:text-gray-400">10 min ago</span>
                    </div>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                      Social Intelligence agent completed "Niche Scout" workflow
                    </p>
                    <div className="mt-2 flex items-center">
                      <span className="badge-gradient-success mr-2">Success</span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">Processed 125 data points</span>
                    </div>
                  </div>
                </div>

                {/* Activity item 2 */}
                <div className="relative flex items-start mb-6">
                  <span className="h-10 w-10 flex items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900 z-10">
                    <FiClock className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </span>
                  <div className="ml-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <p className="font-medium text-gray-900 dark:text-white">Task Started</p>
                      <span className="text-sm text-gray-500 dark:text-gray-400">25 min ago</span>
                    </div>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                      Financial-Tax agent started "Quarterly Tax Report" workflow
                    </p>
                    <div className="mt-2 flex items-center">
                      <span className="badge-gradient-primary mr-2">In Progress</span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">Estimated completion: 35 min</span>
                    </div>
                  </div>
                </div>

                {/* Activity item 3 */}
                <div className="relative flex items-start">
                  <span className="h-10 w-10 flex items-center justify-center rounded-full bg-red-100 dark:bg-red-900 z-10">
                    <FiXCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                  </span>
                  <div className="ml-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                      <p className="font-medium text-gray-900 dark:text-white">Error Detected</p>
                      <span className="text-sm text-gray-500 dark:text-gray-400">45 min ago</span>
                    </div>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                      Legal Compliance agent encountered an error processing documents
                    </p>
                    <div className="mt-2 flex items-center">
                      <span className="badge-gradient-danger mr-2">Error</span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">Auto-retry scheduled</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <button className="btn-sm text-primary-600 dark:text-primary-400 hover:underline font-medium w-full text-center mt-4">
                View All Activity →
              </button>
            </div>
          </div>
        </div>

        {/* Task Distribution & Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Task Distribution */}
          <div className="dashboard-card p-6">
            <h2 className="text-lg font-semibold mb-4">Current Tasks by Type</h2>
            <div className="h-60 flex items-center justify-center">
              <div className="grid grid-cols-2 gap-4 w-full">
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-primary-50 to-primary-100 dark:from-primary-900/30 dark:to-primary-800/30 border border-primary-200 dark:border-primary-800">
                  <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">5</span>
                  <span className="mt-1 text-sm text-gray-600 dark:text-gray-400">Data Analysis</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/30 dark:to-purple-800/30 border border-purple-200 dark:border-purple-800">
                  <span className="text-3xl font-bold text-purple-600 dark:text-purple-400">3</span>
                  <span className="mt-1 text-sm text-gray-600 dark:text-gray-400">Content Generation</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/30 dark:to-green-800/30 border border-green-200 dark:border-green-800">
                  <span className="text-3xl font-bold text-green-600 dark:text-green-400">2</span>
                  <span className="mt-1 text-sm text-gray-600 dark:text-gray-400">Financial Analysis</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900/30 dark:to-yellow-800/30 border border-yellow-200 dark:border-yellow-800">
                  <span className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">2</span>
                  <span className="mt-1 text-sm text-gray-600 dark:text-gray-400">Legal Compliance</span>
                </div>
              </div>
            </div>
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400 text-center">
              Total of 12 active tasks across 4 categories
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="dashboard-card p-6">
            <h2 className="text-lg font-semibold mb-4">Performance Overview</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Response Time</span>
                  <span className="text-sm font-medium text-success-600 dark:text-success-400">Excellent</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-success-500 h-2 rounded-full" style={{ width: '92%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Task Completion Rate</span>
                  <span className="text-sm font-medium text-success-600 dark:text-success-400">Very Good</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-success-500 h-2 rounded-full" style={{ width: '88%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Resource Efficiency</span>
                  <span className="text-sm font-medium text-primary-600 dark:text-primary-400">Good</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '76%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Error Handling</span>
                  <span className="text-sm font-medium text-warning-600 dark:text-warning-400">Needs Improvement</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-warning-500 h-2 rounded-full" style={{ width: '65%' }}></div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-gray-700 mt-4">
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Overall System Health</span>
                  <span className="font-medium text-success-600 dark:text-success-400">
                    94% <span className="text-xs text-gray-500 dark:text-gray-400">(+2.5% this week)</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}