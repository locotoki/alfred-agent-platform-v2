import type { NextApiRequest, NextApiResponse } from 'next';
import { createServerSupabaseClient } from '@supabase/auth-helpers-nextjs';

// Social Intel service URL
const SOCIAL_INTEL_SERVICE_URL = process.env.SOCIAL_INTEL_SERVICE_URL || 'http://social-intel:8000';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Create authenticated Supabase client
    const supabase = createServerSupabaseClient({ req, res });
    
    // Check if user is authenticated
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get the query parameter
    const { query } = req.query;
    
    // Call the Social Intel service
    const params = new URLSearchParams();
    if (query) {
      params.append('query', query as string);
    }

    const response = await fetch(`${SOCIAL_INTEL_SERVICE_URL}/niche-scout?${params.toString()}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const error = await response.json();
      return res.status(response.status).json({ error: error.detail || 'Error calling Social Intel service' });
    }

    const result = await response.json();

    // Save the result to Supabase
    const { data, error } = await supabase
      .from('workflow_results')
      .insert({
        workflow_type: 'niche-scout',
        parameters: { query },
        result,
        user_id: session.user.id,
      })
      .select()
      .single();

    if (error) {
      console.error('Error saving workflow result to database:', error);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in niche-scout API route:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}