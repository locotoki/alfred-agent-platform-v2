import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import MainLayout from '../../components/layout/MainLayout';
import { useQuery } from 'react-query';
import { getScheduledWorkflows, getWorkflowHistory } from '../../services/youtube-workflows';
import { format } from 'date-fns';

export default function Workflows() {
  const router = useRouter();
  
  // Fetch scheduled workflows and history
  const { data: scheduledWorkflows, isLoading: loadingScheduled } = useQuery(
    'scheduledWorkflows', 
    getScheduledWorkflows
  );
  
  const { data: workflowHistory, isLoading: loadingHistory } = useQuery(
    'workflowHistory', 
    getWorkflowHistory
  );

  return (
    <MainLayout title="Workflows">
      <div className="space-y-6">
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            YOUTUBE RESEARCH WORKFLOWS
          </h1>
        </div>

        {/* Workflow Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Niche-Scout Card */}
          <div className="card p-6 h-full flex flex-col">
            <h2 className="text-xl font-bold mb-4">Niche-Scout</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4 flex-grow">
              Find trending YouTube niches with growth metrics
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              <p>Last run: May 5, 2025</p>
              <p>Status: Available</p>
            </div>
            <Link 
              href="/workflows/niche-scout"
              className="btn-primary text-center"
            >
              RUN WORKFLOW
            </Link>
          </div>

          {/* Seed-to-Blueprint Card */}
          <div className="card p-6 h-full flex flex-col">
            <h2 className="text-xl font-bold mb-4">Seed-to-Blueprint</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4 flex-grow">
              Create channel strategy from seed video or niche
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              <p>Last run: May 5, 2025</p>
              <p>Status: Available</p>
            </div>
            <Link 
              href="/workflows/seed-to-blueprint"
              className="btn-primary text-center"
            >
              RUN WORKFLOW
            </Link>
          </div>
        </div>

        {/* Scheduled Runs */}
        <div className="card p-4">
          <h2 className="text-lg font-semibold mb-4">Scheduled Runs</h2>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Workflow</th>
                  <th>Parameters</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {loadingScheduled ? (
                  <tr>
                    <td colSpan={4} className="text-center py-4">Loading...</td>
                  </tr>
                ) : (
                  scheduledWorkflows?.map((workflow, index) => (
                    <tr key={index}>
                      <td>{workflow.frequency}</td>
                      <td>{workflow.workflow_type === 'niche-scout' ? 'Niche-Scout' : 'Seed-to-Blueprint'}</td>
                      <td>
                        {Object.entries(workflow.parameters)
                          .filter(([_, value]) => value)
                          .map(([key, value]) => `${value}`)
                          .join(', ')}
                      </td>
                      <td><span className="status-scheduled">⏱ Scheduled</span></td>
                    </tr>
                  )) || (
                    <>
                      <tr>
                        <td>Daily</td>
                        <td>Niche-Scout</td>
                        <td>gaming</td>
                        <td><span className="status-scheduled">⏱ Scheduled</span></td>
                      </tr>
                      <tr>
                        <td>Weekly</td>
                        <td>Seed-to-Blueprint</td>
                        <td>fitness</td>
                        <td><span className="status-scheduled">⏱ Scheduled</span></td>
                      </tr>
                      <tr>
                        <td>May 8</td>
                        <td>Niche-Scout</td>
                        <td>cooking</td>
                        <td><span className="status-scheduled">⏱ Scheduled</span></td>
                      </tr>
                    </>
                  )
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Workflow History */}
        <div className="card p-4">
          <h2 className="text-lg font-semibold mb-4">Workflow History</h2>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Workflow</th>
                  <th>Parameters</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {loadingHistory ? (
                  <tr>
                    <td colSpan={4} className="text-center py-4">Loading...</td>
                  </tr>
                ) : (
                  workflowHistory?.slice(0, 4).map((workflow, index) => (
                    <tr key={index}>
                      <td>{format(new Date(workflow.started_at), 'MMM d')}</td>
                      <td>{workflow.workflow_type === 'niche-scout' ? 'Niche-Scout' : 'Seed-to-Blueprint'}</td>
                      <td>
                        {Object.entries(workflow.parameters)
                          .filter(([_, value]) => value)
                          .map(([key, value]) => `${value}`)
                          .join(', ')}
                      </td>
                      <td>
                        {workflow.status === 'completed' && (
                          <span className="status-completed">✓ Completed</span>
                        )}
                        {workflow.status === 'running' && (
                          <span className="status-pending">⟳ Running</span>
                        )}
                        {workflow.status === 'error' && (
                          <span className="status-error">✗ Error</span>
                        )}
                      </td>
                    </tr>
                  )) || (
                    <>
                      <tr>
                        <td>May 5</td>
                        <td>Niche-Scout</td>
                        <td>gaming</td>
                        <td><span className="status-completed">✓ Completed</span></td>
                      </tr>
                      <tr>
                        <td>May 5</td>
                        <td>Seed-to-Blueprint</td>
                        <td>gaming</td>
                        <td><span className="status-completed">✓ Completed</span></td>
                      </tr>
                      <tr>
                        <td>May 5</td>
                        <td>Niche-Scout</td>
                        <td>cooking</td>
                        <td><span className="status-completed">✓ Completed</span></td>
                      </tr>
                      <tr>
                        <td>May 4</td>
                        <td>Seed-to-Blueprint</td>
                        <td>fitness</td>
                        <td><span className="status-completed">✓ Completed</span></td>
                      </tr>
                    </>
                  )
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}